/**
 * Contains useful applications including two stand-alone OSM viewers
 * and several demonstrations which combine OSM data with search algorithms
 * and agent concepts from the aima-core library.
 */
package aimax.osm.applications;