package aima.core.probability;

/**
 * @author Ravi Mohan
 * 
 */
public interface Randomizer {
	public double nextDouble();
}
