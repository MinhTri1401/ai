package aima.core.learning.framework;

/**
 * @author Ravi Mohan
 * 
 */
public interface Attribute {
	public String valueAsString();

	public String name();
}
